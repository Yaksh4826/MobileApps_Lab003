package com.example.safique_yaksh_comp304_001_lab003_exercise2

class MovieRepository(private val dao: MovieDao) {
    fun movies(favoritesOnly: Boolean) = if (favoritesOnly) dao.favorites() else dao.all()
    suspend fun get(id: Int) = dao.get(id)
    suspend fun update(movie: Movie) = dao.update(movie)
    suspend fun delete(movie: Movie) = dao.delete(movie)

    /** Returns false (and inserts nothing) if a movie with the same ID already exists. */
    suspend fun add(movie: Movie): Boolean {
        if (dao.get(movie.id) != null) return false
        dao.insert(movie)
        return true
    }

    suspend fun seedIfEmpty() {
        if (dao.count() > 0) return
        dao.insert(
            Movie(101, "Inception", "Christopher Nolan", 19.99, "2010-07-16", 148, "Sci-Fi", true),
            Movie(102, "Titanic", "James Cameron", 14.99, "1997-12-19", 195, "Romance"),
            Movie(103, "The Dark Knight", "Christopher Nolan", 17.99, "2008-07-18", 152, "Action")
        )
    }
}
