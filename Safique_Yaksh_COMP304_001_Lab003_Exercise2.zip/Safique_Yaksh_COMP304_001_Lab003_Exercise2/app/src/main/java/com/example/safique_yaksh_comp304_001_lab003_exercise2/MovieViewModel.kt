package com.example.safique_yaksh_comp304_001_lab003_exercise2

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MovieViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MovieRepository(MovieDatabase.get(app).dao())

    val favoritesOnly = MutableStateFlow(false)

    @OptIn(ExperimentalCoroutinesApi::class)
    val movies = favoritesOnly
        .flatMapLatest { repo.movies(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { viewModelScope.launch { repo.seedIfEmpty() } }

    fun toggleFavorite(m: Movie) = viewModelScope.launch { repo.update(m.copy(favorite = !m.favorite)) }
    fun delete(m: Movie) = viewModelScope.launch { repo.delete(m) }
    suspend fun get(id: Int) = repo.get(id)

    /** onDone(false) means a duplicate ID was rejected. */
    fun save(m: Movie, isNew: Boolean, onDone: (Boolean) -> Unit) = viewModelScope.launch {
        val ok = if (isNew) repo.add(m) else { repo.update(m); true }
        onDone(ok)
    }
}
