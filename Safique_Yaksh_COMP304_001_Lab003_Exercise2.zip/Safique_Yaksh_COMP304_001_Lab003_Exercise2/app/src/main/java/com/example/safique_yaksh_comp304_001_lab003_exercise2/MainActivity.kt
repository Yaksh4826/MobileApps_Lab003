package com.example.safique_yaksh_comp304_001_lab003_exercise2


//Student Names : Yaksh Patel and Mohammed Safique Hossain





import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { MovieApp() } }
    }
}

@Composable
fun MovieApp(vm: MovieViewModel = viewModel()) {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "list") {
        composable("list") {
            MovieListScreen(
                vm,
                onAdd = { nav.navigate("form") },
                onEdit = { nav.navigate("form?id=$it") })
        }
        composable(
            "form?id={id}",
            arguments = listOf(navArgument("id") { type = NavType.IntType; defaultValue = -1 })
        ) { entry ->
            val id = entry.arguments?.getInt("id")?.takeIf { it >= 0 }   // null => "add" mode
            MovieFormScreen(vm, id, onDone = { nav.popBackStack() })
        }
    }
}
