package com.example.safique_yaksh_comp304_001_lab003_exercise2

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MovieDao {
    @Query("SELECT * FROM movies ORDER BY id") fun all(): Flow<List<Movie>>
    @Query("SELECT * FROM movies WHERE favorite = 1 ORDER BY id") fun favorites(): Flow<List<Movie>>
    @Query("SELECT * FROM movies WHERE id = :id") suspend fun get(id: Int): Movie?
    @Query("SELECT COUNT(*) FROM movies") suspend fun count(): Int
    @Insert suspend fun insert(vararg movies: Movie)
    @Update suspend fun update(movie: Movie)
    @Delete suspend fun delete(movie: Movie)
}
