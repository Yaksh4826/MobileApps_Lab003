package com.example.safique_yaksh_comp304_001_lab003_exercise2

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun MovieListScreen(vm: MovieViewModel, onAdd: () -> Unit, onEdit: (Int) -> Unit) {
    val movies by vm.movies.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp)) {
        Text("Movie DVD Manager", style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.semantics { heading() })
        Row(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onAdd) { Text("Add Movie") }
            OutlinedButton({ vm.favoritesOnly.value = false }) { Text("Display All") }
            OutlinedButton({ vm.favoritesOnly.value = true }) { Text("Favorites") }
        }
        if (movies.isEmpty()) Text("No movies to show.")
        // Adaptive grid: one column on phones, several on tablets/foldables
        LazyVerticalGrid(
            GridCells.Adaptive(320.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(movies, key = { it.id }) { m ->
                MovieCard(m, onEdit = { onEdit(m.id) }, onDelete = { vm.delete(m) }, onFavorite = { vm.toggleFavorite(m) })
            }
        }
    }
}

@Composable
private fun MovieCard(m: Movie, onEdit: () -> Unit, onDelete: () -> Unit, onFavorite: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("${m.id} - ${m.title}", style = MaterialTheme.typography.titleMedium)
            Text("Director: ${m.director}")
            Text("Price: $${"%.2f".format(m.price)}")
            Text("Release Date: ${m.releaseDate}")
            Text("Duration: ${m.duration} min")
            Text("Genre: ${m.genre}")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onEdit) { Text("Edit") }
                OutlinedButton(onDelete) { Text("Delete") }
                Spacer(Modifier.weight(1f))
                Text("Favorite")
                Switch(m.favorite, { onFavorite() },
                    modifier = Modifier.semantics { contentDescription = "Favorite ${m.title}" })
            }
        }
    }
}
