package com.example.safique_yaksh_comp304_001_lab003_exercise2

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "movies")
data class Movie(
    @PrimaryKey val id: Int,          // 101..999, supplied by the user
    val title: String,
    val director: String,
    val price: Double,
    val releaseDate: String,          // yyyy-MM-dd
    val duration: Int,                // minutes
    val genre: String,
    val favorite: Boolean = false
)
