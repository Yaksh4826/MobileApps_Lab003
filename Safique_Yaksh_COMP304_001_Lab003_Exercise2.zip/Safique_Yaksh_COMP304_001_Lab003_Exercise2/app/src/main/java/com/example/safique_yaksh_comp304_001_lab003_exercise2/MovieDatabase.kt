package com.example.safique_yaksh_comp304_001_lab003_exercise2

import android.content.Context
import androidx.room.*

@Database(entities = [Movie::class], version = 1, exportSchema = false)
abstract class MovieDatabase : RoomDatabase() {
    abstract fun dao(): MovieDao

    companion object {
        @Volatile private var instance: MovieDatabase? = null
        fun get(context: Context): MovieDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, MovieDatabase::class.java, "movies.db")
                .build().also { instance = it }
        }
    }
}
