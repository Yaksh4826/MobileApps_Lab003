@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.safique_yaksh_comp304_001_lab003_exercise2

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.ZoneOffset

private val GENRES = listOf("Family", "Comedy", "Thriller", "Action", "Sci-Fi", "Romance", "Drama", "Horror")

/** Shared screen: id == null -> Add mode, otherwise Edit mode for that movie. */
@Composable
fun MovieFormScreen(vm: MovieViewModel, id: Int?, onDone: () -> Unit) {
    val existing by produceState<Movie?>(null, id) { value = id?.let { vm.get(it) } }
    if (id == null || existing != null) MovieForm(vm, existing, onDone)
}

@Composable
private fun MovieForm(vm: MovieViewModel, movie: Movie?, onDone: () -> Unit) {
    var id by remember { mutableStateOf(movie?.id?.toString() ?: "") }
    var title by remember { mutableStateOf(movie?.title ?: "") }
    var director by remember { mutableStateOf(movie?.director ?: "") }
    var price by remember { mutableStateOf(movie?.price?.toString() ?: "") }
    var date by remember { mutableStateOf(movie?.releaseDate ?: "") }
    var duration by remember { mutableStateOf(movie?.duration?.toString() ?: "") }
    var genre by remember { mutableStateOf(movie?.genre ?: "") }
    var favorite by remember { mutableStateOf(movie?.favorite ?: false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showDate by remember { mutableStateOf(false) }
    var showGenre by remember { mutableStateOf(false) }

    fun validate(): Movie? {
        val i = id.toIntOrNull(); val p = price.toDoubleOrNull(); val d = duration.toIntOrNull()
        error = when {
            i == null || i !in 101..999 -> "ID must be a 3-digit number (101-999)"
            title.isBlank() || director.isBlank() -> "Title and director are required"
            p == null || p <= 0 -> "Price must be positive"
            date.isBlank() -> "Please select a release date"
            d == null || d <= 0 -> "Duration must be greater than 0"
            genre.isBlank() -> "Please select a genre"
            else -> null
        }
        return if (error == null) Movie(
            i!!,
            title.trim(),
            director.trim(),
            p!!,
            date,
            d!!,
            genre,
            favorite
        ) else null
    }

    Box(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 560.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (movie == null) "Add New Movie" else "Edit Movie", style = MaterialTheme.typography.headlineSmall)
            Field("Movie ID", id, { id = it.take(3) }, enabled = movie == null, keyboard = KeyboardType.Number)
            Field("Title", title, { title = it })
            Field("Director", director, { director = it })
            Field("Price", price, { price = it }, keyboard = KeyboardType.Decimal)
            Field("Release Date", date, readOnly = true)
            Button({ showDate = true }, Modifier.fillMaxWidth()) { Text("Select Release Date") }
            Field("Duration (minutes)", duration, { duration = it }, keyboard = KeyboardType.Number)
            Field("Genre", genre, readOnly = true)
            Box {
                Button({ showGenre = true }, Modifier.fillMaxWidth()) { Text("Select Genre") }
                DropdownMenu(showGenre, { showGenre = false }) {
                    GENRES.forEach { g -> DropdownMenuItem({ Text(g) }, { genre = g; showGenre = false }) }
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Favorite", Modifier.weight(1f))
                Switch(favorite, { favorite = it })
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onDone, Modifier.weight(1f)) { Text("Cancel") }
                Button({
                    validate()?.let { m ->
                        vm.save(m, isNew = movie == null) { ok ->
                            if (ok) onDone() else error = "A movie with ID ${m.id} already exists"
                        }
                    }
                }, Modifier.weight(1f)) { Text("Save") }
            }
        }
    }

    if (showDate) {
        val state = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton({
                    state.selectedDateMillis?.let {
                        date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()
                    }
                    showDate = false
                }) { Text("OK") }
            }
        ) { DatePicker(state) }
    }
}

@Composable
private fun Field(
    label: String, value: String, onChange: (String) -> Unit = {},
    enabled: Boolean = true, readOnly: Boolean = false, keyboard: KeyboardType = KeyboardType.Text
) = OutlinedTextField(
    value, onChange, Modifier.fillMaxWidth(), enabled = enabled, readOnly = readOnly,
    label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = keyboard)
)
